package org.w3c.xqparser;

import java.io.UnsupportedEncodingException;

public class XQueryXConverter extends XQueryXConverterBase {

    public XQueryXConverter() throws UnsupportedEncodingException {
    }

}
